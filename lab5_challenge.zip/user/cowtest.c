#include <ulib.h>
#include <unistd.h>
#include <stdio.h>

static char pagebuf[4096];

int main(void) {
    pagebuf[0] = 'A';
    pagebuf[1] = 'A';

    int pid = fork();
    if (pid < 0) {
        cprintf("fork failed\n");
        return -1;
    }

    if (pid == 0) {
        pagebuf[0] = 'B';
        pagebuf[1] = 'C';
        cprintf("[child] %c %c\n", pagebuf[0], pagebuf[1]);
        exit(0);
    }

    int st = 0;
    waitpid(pid, &st);

    if (pagebuf[0] == 'A' && pagebuf[1] == 'A') {
        cprintf("COW OK\n");
    } else {
        cprintf("COW FAIL: %c %c\n", pagebuf[0], pagebuf[1]);
    }
    return 0;
}
