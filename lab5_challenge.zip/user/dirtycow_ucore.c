#include <ulib.h>
#include <unistd.h>
#include <stdio.h>

static char pagebuf[4096];

// 最小 ecall 封装：a0=num, a1=arg1, a2=arg2，返回值在 a0
static inline long u_syscall2(long num, long arg1, long arg2) {
    register long a0 asm("a0") = num;
    register long a1 asm("a1") = arg1;
    register long a2 asm("a2") = arg2;
    asm volatile("ecall"
                 : "+r"(a0)
                 : "r"(a1), "r"(a2)
                 : "memory");
    return a0;
}

#ifndef SYS_kmemwrite
#define SYS_kmemwrite 32
#endif

int main(void) {
    // 1) fork 前初始化：父子进程最初共享同一物理页（COW 管理）
    pagebuf[0] = 'A';

    int pid = fork();
    if (pid < 0) {
        cprintf("fork failed\n");
        return -1;
    }

    if (pid == 0) {
        // 2) 子进程：只读不写，避免触发 COW 拆分
        //    如果能读到 'X'，说明父进程的“内核绕过写”污染了共享物理页
        for (int i = 0; i < 500000; i++) {
            char v = pagebuf[0];
            if (v == 'X') {
                cprintf("DIRTY COW TRIGGERED: child observed corruption!\n");
                exit(0);
            }
            if ((i & 1023) == 0) {
                yield();
            }
        }
        cprintf("COW SAFE: child never observed corruption, v=%c\n", pagebuf[0]);
        exit(0);
    }

    // 3) 父进程：通过漏洞 syscall 直接写“共享页”（绕过 COW 拆分）
    for (int i = 0; i < 500000; i++) {
        u_syscall2(SYS_kmemwrite, (long)&pagebuf[0], (long)'X');
        if ((i & 1023) == 0) {
            yield();
        }
    }

    waitpid(pid, NULL);

    // 父进程这边看到 X 不算“隔离破坏”的证据（它可能只是写了自己的映射）
    // 真正的证据是：子进程在未写入的情况下读到了 X（上面已打印）
    cprintf("parent sees: %c\n", pagebuf[0]);

    return 0;
}
